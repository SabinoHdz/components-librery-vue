export { default as VBadge } from './VBadge.vue';
export * from './badge';
export * from './badge.variants';
