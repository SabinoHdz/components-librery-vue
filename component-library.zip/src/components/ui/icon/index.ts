/**
 * Icon Component Exports
 * Exporta el componente, tipos, variantes y constantes
 */

export { default as VIcon } from './VIcon.vue';
export * from './icon';
export * from './icon.variants';
