<template>
  <div class="card__title">
    <slot></slot>
  </div>
</template>
