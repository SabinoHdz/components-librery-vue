<template>
  <div class="card__actions">
    <slot></slot>
  </div>
</template>
