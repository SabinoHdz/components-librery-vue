<template>
  <div class="card__subtitle">
    <slot></slot>
  </div>
</template>
