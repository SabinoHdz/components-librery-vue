<template>
  <div class="card__header">
    <slot></slot>
  </div>
</template>
