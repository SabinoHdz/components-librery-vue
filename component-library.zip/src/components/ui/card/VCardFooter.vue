<template>
  <div class="card__footer">
    <slot></slot>
  </div>
</template>
