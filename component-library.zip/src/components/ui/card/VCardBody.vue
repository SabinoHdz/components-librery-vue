<template>
  <div class="card__body">
    <slot></slot>
  </div>
</template>
