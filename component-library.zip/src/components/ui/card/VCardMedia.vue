<template>
  <div class="card__media">
    <slot></slot>
  </div>
</template>
