/**
 * Exportar el componente y tipos
 */

export { default as VTooltip } from './VTooltip.vue';
export * from './tooltip';
export * from './tooltip.variants';
